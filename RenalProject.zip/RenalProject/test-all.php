<?php 
ini_set('display_errors', true);

include('function/function.class.php');

SHOW('Function class page is working');
SHOW_CON();
// SHOW_MYSQL();

// error_reporting(E_ALL);
// ini_set('display_errors', true);
// ini_set('log_errors', true);
// ini_set('track_errors', true);
// ini_set('display_startup_errors', TRUE);
// //error_reporting(E_ALL ^ E_NOTICE);
?>
















